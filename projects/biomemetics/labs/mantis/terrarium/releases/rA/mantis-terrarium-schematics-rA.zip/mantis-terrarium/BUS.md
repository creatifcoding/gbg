# BUS - hybrid power, control, and video rail

## Contact order

| Pin | Net | Function | Geometry |
|---|---|---|---|
| P01 | VIN-A | 12 V rail power, parallel contact A | continuous land |
| P02 | VIN-B | 12 V rail power, parallel contact B | continuous land |
| P03 | GND-A | power/control return A | continuous land |
| P04 | GND-B | power/control return B | continuous land |
| P05 | SDA | 3.3 V I2C | continuous land |
| P06 | SCL | 3.3 V I2C | continuous land |
| P07 | UID | unique 1-Wire ROM identity | continuous land |
| P08 | MUTE/IRQ | hardware mute/interlock plus optional interrupt | continuous land |
| P09 | HSGND | high-speed ground fence | discrete V-dock |
| P10 | GMSL+ | GMSL2 positive | discrete V-dock |
| P11 | GMSL- | GMSL2 negative | discrete V-dock |
| P12 | HSGND | high-speed ground fence | discrete V-dock |

P09-P12 form a characterized high-speed spring-contact cell. Their physical pitch, ground-via fence, pad shape, antipad, dielectric, launch, and spring-contact series remain `UNVERIFIED`; the 2.54 mm drawing pitch is a packaging target, not a released transmission-line geometry.

## Camera signal path

`IMX519 B0371 -> local MIPI CSI-2 -> MAX96717 -> GMSL2 over locked P09-P12 -> MAX96724 -> short 22-position 0.5 mm CSI-2 -> Tachyon`

The carriage has no cable tether. Raw MIPI never becomes a continuous multidrop rail. Each V-dock is separately routed point-to-point as a 100 ohm target channel to one MAX96724 input. Release A supports four V-docks per video rail and one camera carriage; the deserializer architecture can grow later.

## Mate / move state machine

1. `ABSENT`: all contacts open; rail branch off.
2. `MECHANICALLY SEATED`: alignment bosses and clamp shoulders are seated; S1 remains open.
3. `POWER-MATED`: low-speed contacts stable; S1 closes after mechanical dwell; Q1 soft-enables VIN.
4. `LINK-TRAINED`: serializer and deserializer report lock; video is admitted.
5. `PINCH-MUTE`: first pinch travel opens S1, asserts MUTE, disables Q1, and isolates low-speed bus.
6. `LIFTED`: all contacts clear by at least the target lift; rollers may translate.

No video or power is specified while rolling. A mechanical cam dwell must ensure `PINCH-MUTE` precedes contact lift. Timing, debounce, discharge, and fail-safe polarity require EVT measurement.

## Fault policy

- No GMSL lock, wrong dock, bent HSD contact, UID loss, or partial clamp: keep Q1 off and report fault.
- Overcurrent or short: current limiter acts first; F1 is the final branch fuse.
- SDA/SCL stuck low: isolate the segment; do not re-energize until service.
- Pogo bounce during pinch: hardware mute and power-off state dominates software.
- Position: inferred from active MAX96724 port V1-V4, never from UID alone.
- Camera configuration uses the GMSL reverse control channel; the general rail I2C remains for sensor/actuator loads.

## Validation gates

- 3 and 6 Gbps eye/BER and return-loss tests through the complete locked spring-contact channel.
- Contact skew, bounce, ESD, contamination, wear, and 10,000-cycle target.
- Q1 current limit, fuse coordination, contact temperature rise, and two-contact current sharing.
- I2C capacitance and pull-up tuning; Particle recommends keeping the Qwiic chain below roughly 100 mA.
- Serializer/deserializer driver and device-tree integration on the exact Tachyon OS image.
