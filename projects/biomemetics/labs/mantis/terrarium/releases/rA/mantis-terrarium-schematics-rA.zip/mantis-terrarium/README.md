# Particle-base mantis terrarium - theoretical schematic release A

This package is a theory drawing set for a 250 x 250 x 500 mm modular mantis terrarium. No live-mantis or commercial-frame photo was supplied, so taxonomy is intentionally unset and all custom geometry that is not a source lock is marked `REF`, `TARGET`, or `UNVERIFIED`.

Release A incorporates a tetherless camera-carriage architecture: raw MIPI CSI-2 remains inside the camera binder, a MAX96717 serializer converts it to GMSL2, and power plus serialized video cross a 12-contact spring array at discrete high-speed rail docks. A MAX96724 outside the animal volume converts up to four point-to-point dock links back to CSI-2 for Tachyon.

The high-speed rail is theoretical and is not released for animal use. It requires signal-integrity coupons, eye/BER testing, contact-bounce testing, ESD validation, thermal testing, and a mechanically interlocked power/mute sequence.

## Files

- `cad/mantis_terrarium.scad` - portable parametric source; OpenSCAD was not available in the authoring environment, so regenerate and inspect it before fabrication.
- `schematics/S00-cover.svg` through `schematics/S11-details.svg` - A3 vector source sheets.
- `schematics/schematics.pdf` - ordered combined set.
- `BOM.md`, `PARAMS.md`, and `BUS.md` - balloon identities, locked/provisional dimensions, and interface definition.

## Status vocabulary

- `LOCK` - explicitly required by the supplied source prompt.
- `DERIVED` - arithmetic consequence of locks.
- `REF` - provisional geometry, not measured.
- `TARGET` - test goal, not verified performance.
- `UNVERIFIED` - vendor drawing, selected part, or bench evidence is still required.
