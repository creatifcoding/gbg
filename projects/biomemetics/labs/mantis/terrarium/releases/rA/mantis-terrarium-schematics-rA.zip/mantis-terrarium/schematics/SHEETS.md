# Schematic index - release A

All sheets are A3 landscape, millimetres, third-angle where physical projection applies, and carry `THEORETICAL - VERIFY AGAINST STEP / FIRST ARTICLE` in the title block.

| Sheet | Scale | What it proves | Principal unverified items |
|---|---|---|---|
| S00 Cover / theory | 1:5 | Exterior rail/brick and protected animal boundary | all custom first-article geometry |
| S01 Orthographic assembly | 1:5 | 250 x 250 x 500 envelope, third-angle arrangement, upper-third datum | finished joint and gasket closure |
| S02 Exploded assembly | 1:5 | functional service order and external electronics | fastener and retainer selections |
| S03 Perimeter blocks | 1:2; 2:1 details | corner/edge/splice/cassette logic and 250-to-500 joint | block section, groove, coupler |
| S04 Rail + strip | 2:1; 5:1 details | 12-contact split and four point-to-point GMSL2 docks | all SI geometry and contact series |
| S05 Carriage mechanism | 2:1; 5:1 | mute-lift-roll-lock kinematics and split contact carrier | spring, cam, roller, travel, forces |
| S06 Universal latch + binder | 2:1; 5:1 | common bind datum and camera load path | pull-off, wear key, electric handoff carrier |
| S07 Camera SerDes load | 2:1; 1:1 PCB | tetherless IMX519 -> MAX96717 -> pogo GMSL2 topology | carrier PCB, internal FPC, binder thermals |
| S08 Electrical/video schematic | 1:1 symbol grid | protected rail power, interlock, UID, GMSL2 and MAX96724 | Q1/S1 exact circuit and Tachyon driver |
| S09 SerDes/Particle brick | 1:1; diagram | MAX96724-to-Tachyon CSI and optional M1 external placement | carrier and OS integration |
| S10 Husbandry interference | 1:5; 5:1 | no metal in wet volume, molt keep-out, vents, door and drain | seals, airflow, nymph tests |
| S11 Detail blow-ups | 5:1; 10:1 | pogo bore, wipe/dock, spring pocket, FPC relief, magnet and splice | every tolerance marked TARGET/UNVERIFIED |

## Release-blocking validation

- Import the Particle Tachyon CAD, Arducam B0371 STEP, and selected spring-contact models.
- Close the 100 ohm V-dock channel using field-solver/S-parameters, then pass 3/6 Gbps eye and BER testing.
- Prove S1/Q1 mute-before-lift sequencing under the fastest possible pinch.
- Run temperature-rise and fuse-coordination tests at the target rail current.
- Print cassette, slide, pogo-bore, latch, and block-joint coupons before full parts.
- Perform wet-volume, nymph-gap, screen-sag, door-swing, and molt-zone inspection before introducing an animal.

## Primary technical sources checked 2026-08-20

- [Particle Tachyon datasheet](https://docs.particle.io/reference/datasheets/tachyon/tachyon-datasheet/)
- [Particle Tachyon camera documentation](https://developer.particle.io/tachyon/device-details/cameras)
- [Particle M1 enclosure datasheet](https://docs.particle.io/reference/datasheets/m-series/m1-enclosure-datasheet/)
- [Arducam B0371 IMX519 module](https://www.arducam.com/imx519-autofocus-camera-module-for-raspberry-pi-arducam-b0371.html)
- [Analog Devices MAX96717](https://www.analog.com/en/products/max96717.html)
- [Analog Devices MAX96724](https://www.analog.com/en/products/max96724.html)
- [Samtec spring/compression RF interconnect references](https://www.samtec.com/rf/connectors/magnum/)
