// Particle-base mantis terrarium - theoretical parametric source
// Units: mm. All non-locked geometry is REF and must be verified on first article.
$fn = 48;

pitch_mm = 250;          // LOCK
span_mm = 500;           // LOCK
frame_w = 24;            // REF
frame_d = 24;            // REF
panel_t = 3.0;           // REF stock
cassette_clearance = 0.20; // TARGET each seat system
rail_w = 38;             // REF: 8 low-speed + 4 guarded high-speed contacts
rail_h = 16;             // REF
rail_offset = 5;         // REF external clearance
carriage_w = 60;         // REF
carriage_d = 42;         // REF
carriage_h = 28;         // REF
strip_count = 12;        // 8 power/control + G,HSD+,HSD-,G video dock cell
pogo_pitch = 2.54;       // TARGET

module edge_block(length=pitch_mm) {
  difference() {
    cube([length, frame_w, frame_d]);
    translate([4, 4, 4]) cube([length-8, frame_w-8, frame_d]);
    // cassette pocket: nominal 3.2 REF
    translate([0, 10, 8]) cube([length, panel_t + cassette_clearance, 10]);
  }
}

module corner_post(height=span_mm) {
  difference() {
    cube([frame_w, frame_d, height]);
    translate([8,8,0]) cube([frame_w,frame_d,height]);
    translate([4,10,0]) cube([panel_t+cassette_clearance,10,height]);
    translate([10,4,0]) cube([10,panel_t+cassette_clearance,height]);
  }
}

module rail(length=pitch_mm) {
  difference() {
    cube([length, rail_w, rail_h]);
    translate([0,4,4]) cube([length, rail_w-8, rail_h-4]);
    translate([0,7,0]) cube([length, rail_w-14, 5]);
  }
}

module strip(length=pitch_mm) {
  // P01-P08 continuous power/control lands.
  for (i=[0:7])
    translate([0, i*pogo_pitch, 0]) cube([length,1.50,0.2]);
  // P09-P12 are guarded high-speed cells at four discrete V-docks.
  for (dock=[0:3], i=[8:11])
    translate([25 + dock*((length-50)/3), i*pogo_pitch, 0]) cube([18,1.50,0.2]);
}

module carriage() {
  difference() {
    hull() {
      cube([carriage_w,carriage_d,carriage_h-6]);
      translate([3,3,carriage_h-6]) cube([carriage_w-6,carriage_d-6,6]);
    }
    translate([6,6,0]) cube([carriage_w-12,carriage_d-12,carriage_h]);
    translate([carriage_w/2-10,0,4]) cube([20,carriage_d,8]);
  }
}

module terrarium_assembly(exploded=0) {
  // Four exterior posts
  for (x=[0,pitch_mm-frame_w], y=[0,pitch_mm-frame_d])
    translate([x,y,0]) corner_post();
  // Top and bottom edge members
  for (z=[0,span_mm-frame_d]) {
    translate([0,0,z]) edge_block();
    translate([0,pitch_mm-frame_w,z]) edge_block();
    translate([0,0,z]) rotate([0,0,90]) edge_block();
    translate([pitch_mm-frame_w,0,z]) rotate([0,0,90]) edge_block();
  }
  // External top-front rail
  translate([0,-rail_w-rail_offset,span_mm-rail_h+exploded]) rail();
  translate([0,-rail_w-rail_offset+7,span_mm-rail_h+5+exploded]) strip();
  translate([pitch_mm*0.25,-rail_w-rail_offset-4,span_mm+exploded*2]) carriage();
}

terrarium_assembly(0);
